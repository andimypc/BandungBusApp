package com.dicoding.picodiploma.bandungbus

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Bus (
    var trayek: String,
    var kepergian: String,
    var kepulangan: String

): Parcelable