package com.dicoding.picodiploma.bandungbus

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: BusAdapter
    private lateinit var dataTrayek: Array<String>
    private lateinit var dataKepergian: Array<String>
    private lateinit var dataKepulangan: Array<String>
    private var busses = arrayListOf<Bus>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val listView: ListView = findViewById(R.id.lv_list)

        adapter = BusAdapter(this)

        listView.adapter = adapter


        prepare()
        additem()

        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val moveIntent = Intent(this@MainActivity, Details::class.java)
            val selectedBus: Bus = busses[position]
            moveIntent.putExtra(Details.KEY_BUS, selectedBus)
            startActivity(moveIntent)

        }


    }

    private fun additem() {
        for (position in dataTrayek.indices) {
            val bus = Bus(
                dataTrayek[position],
                dataKepergian[position],
                dataKepulangan[position]
            )
            busses.add(bus)
        }

        adapter.busses = busses
    }
    private fun prepare() {
        dataTrayek = resources.getStringArray(R.array.trayek)
        dataKepergian = resources.getStringArray(R.array.kepergian)
        dataKepulangan = resources.getStringArray(R.array.kepulangan)
    }

}