package com.dicoding.picodiploma.bandungbus

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class BusAdapter internal constructor(private val context: Context) : BaseAdapter() {
    internal var busses = arrayListOf<Bus>()

    override fun getView(position: Int, view: View?, viewGroup: ViewGroup?): View {
        var itemView = view
        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.item_bus, viewGroup, false)
        }
        val viewHolder = ViewHolder(itemView as View)
        val anggota = getItem(position) as Bus
        viewHolder.bind(anggota)
        return itemView
    }

    private inner class ViewHolder internal constructor(view: View) {
        private val txtTrayek: TextView = view.findViewById(R.id.txt_trayek)

        internal fun bind(bus: Bus) {
            txtTrayek.text = bus.trayek
        }
    }
    override fun getItem(i: Int): Any = busses[i]
    override fun getItemId(i: Int): Long = i.toLong()
    override fun getCount(): Int = busses.size
}